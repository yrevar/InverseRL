''' Setup example scripts run (even without simple_rl fully installed).'''
import os
import sys
parent_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
sys.path.insert(0, parent_dir)